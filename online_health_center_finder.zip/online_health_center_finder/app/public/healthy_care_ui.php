<?php require_once("../includes/initialize.php"); ?>

<?php

	if(isset($_GET['id'])){
		$id = $_GET['id'];
		$healthyCenter = healtyCenter::find_by_id($id);

		$specialists_sql = "SELECT * FROM specialists WHERE healthy_center_id=".$id;
		$service_sql = "SELECT * FROM service_price WHERE healthy_center_id=".$id;

		$spec_result_set = $database->query($specialists_sql);
		$service_result_set = $database->query($service_sql);

		if(!$database->fetch_array($spec_result_set) && !$database->fetch_array($service_result_set)){
		}	

		$spec_result_set = $database->query($specialists_sql);
		$service_result_set = $database->query($service_sql);
	}
?>


<?php include_layout_template('header.php'); ?>

<style>
.mySlides {display:none}
.w3-left, .w3-right, .w3-badge {cursor:pointer}
.w3-badge {height:13px;width:13px;padding:0}
</style>

<!-- real estate START -->
<div class="w3-container w3-section w3-card-4 real-estate-ui">
	<?php
		echo "<div id='lat' style='display:none;'>".$healthyCenter->lat."</div>";
		echo "<div id='lon' style='display:none;'>".$healthyCenter->lon."</div>";
	?>
	<h1 class="w3-center"><?php echo $healthyCenter->name; ?></h1>
	<hr  style="border-color: silver; width: 96%; margin-left: 2%;" />
	<div class="w3-contaner" style="padding: 20px; overflow: auto">
			<p><img src="<?php echo $healthyCenter->img;?>" alt="Healty Center" height="170" width="200" align="left"
			style="padding-right: 10px;"><?php echo $healthyCenter->discription; ?></p>
	</div>
	<hr  style="border-color: silver; width: 96%; margin-left: 2%;" />
	<div class="w3-container w3-section specialist">
		<h2>Specialists</h2>
		<hr style="width: 20%; border-color:silver; position: relative; top: -20px;" />
		<table class="specialist-table">
			<tr>
				<td><b>Working Hour</b></td>
				<td><b>On Duty Specialist</b></td>
			</tr>
			<?php
				$i = 0;
				while ($row = $database->fetch_array($spec_result_set)) {
					echo "<tr";
					if($i % 2 == 1){echo " class='w3-blue' ";} 
					echo ">";
					echo "<td>".$row['working_hour']."</td>";
					echo "<td>".$row['specialist']."</td>";
					echo "</tr>";
					$i++;
			    }

			?>
		</table>
	</div>
	<hr style="border-color: silver; width: 96%; margin-left: 2%;" />
	<div class="w3-container w3-section service">
		<h2>Service Price</h2>
		<hr style="width: 20%; border-color:silver; position: relative; top: -20px;" />
		<table class="specialist-table">
			<tr>
				<td><b>Service</b></td>
				<td><b>Price</b></td>
			</tr>
			<?php
				$i = 0;
				while ($row = $database->fetch_array($service_result_set)) {
					echo "<tr";
					if($i % 2 != 0){echo " class='w3-blue' ";} 
					echo ">";
					echo "<td>".$row['service']."</td>";
					echo "<td>".$row['price']."</td>";
					echo "</	tr>";
					$i++;
				}

			?>
		</table>
	</div>
	<!-- map START -->
	<div class="w3-container w3-border real-estate-map" id="googleMap">	
	</div>
	<!-- map END -->
</div>
<!-- real estate END -->
<script>
var slideIndex = 1;
showDivs(slideIndex);

function plusDivs(n) {
  showDivs(slideIndex += n);
}

function currentDiv(n) {
  showDivs(slideIndex = n);
}

function showDivs(n) {
  var i;
  var x = document.getElementsByClassName("mySlides");
  var dots = document.getElementsByClassName("demo");
  if (n > x.length) {slideIndex = 1}    
  if (n < 1) {slideIndex = x.length} ;
  for (i = 0; i < x.length; i++) {
     x[i].style.display = "none";  
  }
  for (i = 0; i < dots.length; i++) {
     dots[i].className = dots[i].className.replace(" w3-white", "");
  }
  x[slideIndex-1].style.display = "block";  
  dots[slideIndex-1].className += " w3-white";
}
</script>

<?php include_layout_template('footer.php'); ?>

<script>

var lat = $('#lat').text();
var lon = $('#lon').text();

var myCenter=new google.maps.LatLng(lat, lon);

function initialize()
{
var mapProp = {
  center:myCenter,
  zoom:6,
  mapTypeId:google.maps.MapTypeId.ROADMAP
  };

var map=new google.maps.Map(document.getElementById("googleMap"),mapProp);

var marker=new google.maps.Marker({
  position:myCenter,
  });

marker.setMap(map);
}

google.maps.event.addDomListener(window, 'load', initialize);
</script>	