<?php require_once("../includes/initialize.php"); 

if($session->is_logged_in()){
	$session->logout();
	redirect_to("./sign_in_ui.php");
} else {
	redirect_to("./sign_in_ui.php");
}