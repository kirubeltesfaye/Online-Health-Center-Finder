<?php require_once("../includes/initialize.php"); ?>

<?php include_layout_template('header.php'); ?>

<!-- grid view START -->
<div class="w3-container w3-card-2 w3-section map">
	<div class="w3-container" id="about">
		<h2>About Us</h2>
		<p>Health Net Ethiopia is dedicated in helping those who are in critical need of</p>
		<p>medical treatment and health centers</p>
		<p>contact us : tell-251-911-96-58-55</p>
		<p>Email :HealthNetEthiopia@gmail.com</p>
		<p>through our website :www.Health Net Ethiopia.com</p>
		<p>-PoBox : 5544/00</p>
		<p>- Fax :25192678182300</p>
	</div>
</div>

<?php include_layout_template('footer.php'); ?>

<script type="text/javascript">
	$("#about h2").addClass("w3-center");
	$("#about p").addClass("w3-center");
</script>

