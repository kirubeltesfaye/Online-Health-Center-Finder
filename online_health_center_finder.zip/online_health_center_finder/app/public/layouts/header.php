<?php require_once("../includes/session.php"); ?>

<!DOCTYPE html>
<html>
<head>
	<title>Health Net Ethiopia</title>
	<link rel="stylesheet" href="stylesheets/w3.css">
	<link rel="stylesheet" href="stylesheets/main.css">
	<!-- <script
		src="http://maps.googleapis.com/maps/api/js?key=AIzaSyBxSZ1MBmJtFfHbm3qRFyI7d-i74-_qcBY">
	</script> -->
</head>
<body>
	<div class="w3-container w3-top w3-white header" id="header">
		<!-- START main header-->
		<div class="w3-container w3-bottombar w3-border-blue">
			<!--logo-->
			<div class="logo w3-container">
				<img src="images/logo.jpg" height="60" width="100" id="logo-hat">
			</div>
			
			<!-- START navigation-->
			<div class="nav">
				<?php
					$healthyCenter = healtyCenter::find_all();
					$disease_cate = DiseaseCategory::find_all();

					echo "<a href='index.php' class='w3-btn w3-white w3-section w3-hover-blue
							w3-border-right w3-border-black'>Home</a>";
					echo "<div class='w3-dropdown-hover'>
						  <button class='w3-btn w3-white w3-hover-blue w3-border-right w3-border-black'>Healthy Centers</button>
						  <div class='w3-dropdown-content w3-border'>";

						  for ($i=0; $i < count($healthyCenter); $i++) { 
						  	echo "<a href='healthy_care_ui.php?id=".$healthyCenter[$i]->id."' class='w3-hover-blue'>".$healthyCenter[$i]->name."</a>";
						  }
					echo "</div>
						</div>";

					echo "<div class='w3-dropdown-hover'>
						  <button class='w3-btn w3-white w3-hover-blue w3-border-right w3-border-black'>Disease</button>
						  <div class='w3-dropdown-content w3-border'>";

						  for ($i=0; $i < count($disease_cate); $i++) { 
						  	echo "<a href='disease_ui.php?id=".$disease_cate[$i]->id."' class='w3-hover-blue'>".$disease_cate[$i]->category_name."</a>";
						  }

					echo "</div>
						</div>";

					echo "<a href='about_us.php' class='w3-btn w3-white w3-section w3-hover-blue '>About Us</a>";


				?>

				<form method="get" action="search.php" class="search_form">
					<input type="search" name="search_body" class="w3-round search_box" style="padding: 3px; position: relative; top: 3px;">
					<input type="submit" name="search" value="search" class="w3-btn w3-round w3-blue">
				</form>

			</div>
			<!-- END navigation -->
			
		</div>
		<!-- END main header -->
	</div>
	<div id="clone_header">
		
	</div>