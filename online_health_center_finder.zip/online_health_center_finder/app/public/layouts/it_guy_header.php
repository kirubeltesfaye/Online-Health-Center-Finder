<!DOCTYPE html>
<html>
<head>
	<title>Health Net Ethiopia</title>
	<link rel="stylesheet" href="../stylesheets/w3.css">
	<link rel="stylesheet" href="../stylesheets/main.css">

</head>
<body>
	<div class="w3-container w3-top w3-white header" id="header">
		<!-- END top small bar header -->
		<!-- START main header-->
		<div class="w3-container w3-bottombar w3-border-blue">
			<!--logo-->
			<div class="logo w3-container">
				<img src="../images/logo.jpg" height="60" width="100" id="logo-hat">
			</div>
			
			<!-- START navigation-->
			<div class="nav">
				<a href="log_out.php" class='w3-btn w3-white w3-section w3-round w3-hover-blue'>Log Out</a>
			</div>
			<!-- END navigation -->
			
		</div>
		<!-- END main header -->
	</div>
	<div id="clone_header">
		
	</div>