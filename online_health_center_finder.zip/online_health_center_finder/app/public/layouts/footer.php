		<div class="w3-container w3-topbar w3-border-blue footer" id="footer">
			<p style="position: center;">Copyright &#169; 2017 Health Net Ethiopia. Health Net Ethiopia is not responsible for the content of external sites.Read about our approach to external linking</p>
		</div>
		<script type="text/javascript" src="javascripts/jquery-1.11.0.min.js"></script>
		<script type="text/javascript" src="javascripts/layout.js"></script>
		<script type="text/javascript">
			$(document).ready(function() {
				var g = $("#footer").offset();
				if(g.top < 600){
					$("#footer").offset({top:600});
				}
			});
		</script>
	</body>
</html>