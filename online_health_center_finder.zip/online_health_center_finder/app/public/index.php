<?php require_once("../includes/initialize.php"); ?>

<?php

if(isset($_POST["doc_log_out"])){
	$session->logout();
	redirect_to('admin/sign_in_ui.php');
}
	

?>

<?php include_layout_template('header.php'); ?>

<!-- grid view START -->
<?php

	if($session->is_logged_in() && $session){
		$user =  Admin::find_by_id($session->user_id);
		if($user->type == "doctor"){
			echo "<div>";
			echo "<form accept='index.php' method='post'>";
			echo "<input type='submit' name='doc_log_out' value='Log Out' class='w3-btn w3-blue w3-round log_out_home_btn'>";
			echo "</form>";
			echo "</div>";
		}
	}	

?>
<div class="w3-container w3-card-2 w3-section map">
	<!-- slid START -->
	<div class="w3-content w3-section" style="max-width:100%">
	  <!-- <img class="mySlides" src="images/Paulos-hospial.jpg" style="width:100%">
	  <img class="mySlides" src="images/Tikur-Anbessa.jpg" style="width:100%">
	  <img class="mySlides" src="images/yekatit-12.jpg" style="width:100%">
	  <img class="mySlides" src="images/zewditu.jpg" style="width:100%"> -->
	  <?php 

	  	$healthyCenter = healtyCenter::find_all();
	  	for ($i=0; $i < count($healthyCenter); $i++) { 
	  		echo "<img class='mySlides' src='".$healthyCenter[$i]->img."' style='width:100%'>";
	  	}
	  	
	  ?>
	</div>
	<!-- slid END -->
	<!-- post form START -->
	<?php 

		if($session->is_logged_in()){
			$user = Admin::find_by_id($session->user_id);
			if($user->type == "doctor"){
				echo "<div class='w3-container w3-section posts'>";
				echo "<div class='w3-container w3-card-2 w3-section post' style='padding: 10px;'>";
				echo "<form action='post.php' method='post'>";
				echo "<input type='text' name='post_body' placeholder='Post Content' class='w3-input w3-border w3-section' style='width: 70%; display: inline;' required=''>";
				echo " ";
				echo "<input type='submit' name='post' value='Post' class='w3-btn w3-blue' 
				style='padding: 9px 16px 9px 16px; position: relative; top: -2px;'>";
				echo "</form>";
				echo "</div>";
				echo "</div>";
			}

		}
	?>
	<!-- post form END -->
	<!-- post START -->

	<?php

		$posts = Post::find_all();
		for ($i=0; $i < count($posts); $i++) { 
			echo "<div class='w3-container w3-section posts'>";
			echo "<div class='w3-container w3-card-2 w3-section post'>";
			echo "<h2>".$posts[$i]->author."</h2>";
			echo "<h3 class='w3-container'>".$posts[$i]->body."</h3>";
			echo "<hr style='border-color: black;' />";
			echo "<div id='shadow".$posts[$i]->id."' style='display: none;'>";
			$comments = \App\Includes\Comment::find_by_post_id($posts[$i]->id);
			if($comments){
				for ($k=0; $k < count($comments); $k++) { 
						echo "<div>
							<p>".$comments[$k]->body."</p>
							<hr  style='border-color: silver;'/>
						</div>";
					}
			}
			echo "<form action='comment.php' method='post'>
					<input type='hidden' value='".$posts[$i]->id."' name='hidden_id'>
					<input type='text' name='comment_body' placeholder='Comment Here' class='w3-input w3-border w3-section' style='width: 70%; display: inline;'>
					<input type='submit' name='comment' value='Comment' class='w3-btn w3-blue' style='padding: 9px; position: relative; top: -2px;'>
				</form>";
			echo "</div>";
			echo "<div id='shadow_caller".$posts[$i]->id."'>
				<button class='w3-btn w3-blue w3-right' onclick='show_comments(".$posts[$i]->id.");' style='position: relative; top: -10px;'>
				More
				</button>
			</div>";
			echo "</div></div>";
		}

	?>
	<!-- post END -->
</div>

<!-- grid view END -->

<!-- special options START -->

<script>
	var myIndex = 0;
	carousel();

	function carousel() {
	    var i;
	    var x = document.getElementsByClassName("mySlides");
	    for (i = 0; i < x.length; i++) {
	       x[i].style.display = "none";  
	    }
	    myIndex++;
	    if (myIndex > x.length) {myIndex = 1}    
	    x[myIndex-1].style.display = "block";  
	    setTimeout(carousel, 2000); // Change image every 2 seconds
	}
</script>

<?php include_layout_template('footer.php'); ?>

<script>
	function show_comments(id){
		var comment_id = "#shadow" + id;
		var comment_caller_id = "#shadow_caller" + id;
		$(comment_id).css("display","block");
		$(comment_caller_id).css("display","none");
	}
</script>
