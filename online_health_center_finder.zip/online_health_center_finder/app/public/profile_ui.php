<?php require_once("../includes/initialize.php"); ?>

<?php
	if(isset($_SESSION['user_id'])){
		$currentUser = User::find_by_id($_SESSION['user_id']);
	} else {
		redirect_to("sign_in_ui.php");
	}
?>

<?php include_layout_template('header.php'); ?>

<!-- profile page START -->
<div class="w3-container profile">
	<!-- side nav START -->
	<div class="left-nav">
		<!-- profile link -->
		<a href="javascript: void(0)" onclick="showProfile()" class="w3-btn-block w3-left-align w3-white w3-border-bottom w3-hover-amber">Profile</a>
		<!-- inbox link -->
		<div class="w3-accordion">
			<a onclick="myAccFunc()" href="#" class="w3-btn-block w3-left-align w3-white w3-hover-amber w3-border-bottom">
			  Inbox <i class="fa fa-caret-down"></i>
			</a>
			<div id="demoAcc" class="w3-accordion-content w3-white w3-card-4">
			  <a href="#">Link 1</a>
			  <a href="#">Link 2</a>
			  <a href="#">Link 3</a>
			</div>
		</div>
		<a href="log_out.php" class="w3-btn-block w3-left-align w3-white w3-border-bottom w3-hover-amber">Log Out</a>
	</div>
	<!-- side nav END -->
	<!-- nav view START -->
	<div class="nav-body w3-border-left" id="nav-body">
		<p>nav body</p>
	</div>
	<!-- nav view END -->
</div>

<!-- profile body START -->
<div id="profile-body" style="display: none;">
	<div class="w3-container"> 
		<div class="w3-container w3-border-bottom"> <!--for profile pic-->
			<h3>Profile Picture</h3>
			<div class="w3-card w3-border-white profile-pic">
				<img src="images/avatar.png" alt="Profile" width="20%" height="20%">
			</div>
		</div>
		<div class="w3-container w3-border-bottom"> <!--for user name-->
 			<h3>User Name</h3>
 			<P><?php echo $currentUser->full_name();?></P>
		</div> 
		<div class="w3-container w3-border-bottom"> <!--for email-->
			<h3>Email</h3>
 			<P><?php echo $currentUser->email;?></P>
		</div> 
		<div class="w3-container w3-border-bottom"> <!--for password-->
			<h3>Password</h3>
			<p><a href="">Change Password</a>
		</div>
		<div class="w3-container w3-border-bottom"> <!--for location-->
			<h3>Location</h3>
			<p><?php echo $currentUser->location;?> <a href="">Change Password</a></p>
		</div>
	</div>
</div>
<!-- profile body END -->

<!-- profile page END -->

<?php include_layout_template('footer.php'); ?> 

<script type="text/javascript">
	var navBody = $("#nav-body");
	var profileBody = $("#profile-body").html();
	navBody.html(profileBody);

	function myAccFunc() {
	    var x = document.getElementById("demoAcc");
	    if (x.className.indexOf("w3-show") == -1) {
	        x.className += " w3-show";
	        x.previousElementSibling.className += " w3-green";
	    } else { 
	        x.className = x.className.replace(" w3-show", "");
	        x.previousElementSibling.className = 
	        x.previousElementSibling.className.replace(" w3-green", "");
	    }
	}
	var navBody = $("#nav-body");
	function showProfile() {
		var profileBody = $("#profile-body").html();
		navBody.html(profileBody);
	}

</script>