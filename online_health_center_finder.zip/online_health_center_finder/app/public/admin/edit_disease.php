<?php require_once("../../includes/initialize.php"); ?>

<?php

	if (isset($_GET['id'])) {
		$id = $_GET['id'];
		$diseases = Disease::find_by_cate_id($id);
		$disease_cate = DiseaseCategory::find_by_id($id);
	}

	if(!$session->is_logged_in()){
		redirect_to('sign_in_ui.php');	
	}

?>

<?php include_layout_template('admin_header.php'); ?>

<div class="w3-container w3-card-2 w3-account account-view">
	<div class="w3-container w3-right w3-section" style="position: relative; top: 15px; right: 5px;">
		<a href="add_disease_ui.php?id=<?php echo $id;?>" class="w3-btn w3-blue">+ Add</a>
	</div>
	
	<h1 class="w3-container w3-section"><?php echo $disease_cate->category_name;?></h1>
	<hr class="w3-border-black" />
	<?php	
		if($diseases){
			for ($i=0; $i < count($diseases); $i++) { 
				echo "<div class='w3-container w3-section'>";
				echo "<span style='font-size: 18px; float: left;'>".$diseases[$i]->name."</span>";
				echo "<span style='float: right; width: 10%;'>";
				echo "<a href='delete_disease.php?id=".$diseases[$i]->id."' class='w3-btn w3-blue'>Delete</a>";
				echo "</span>";
				echo "</div>";
				echo "<hr />";
			}
		} else {
			echo "<div class='w3-container w3-section'>";
			echo "<p>No Disease</p>";
			echo "</div>";
		}

	?>
</div>
	
<?php include_layout_template('admin_footer.php'); ?> 