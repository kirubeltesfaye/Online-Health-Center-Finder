<?php require_once("../../includes/initialize.php"); ?>


<?php

	$user_id = $session->user_id;
	$user = Admin::find_by_id($user_id);
	$id = $user->healthy_center_id;
	$healthyCenter = healtyCenter::find_by_id($id);

	$specialists_sql = "SELECT * FROM specialists WHERE healthy_center_id=".$id;
	$service_sql = "SELECT * FROM service_price WHERE healthy_center_id=".$id;

	$spec_result_set = $database->query($specialists_sql);
	$service_result_set = $database->query($service_sql);

	if(!$database->fetch_array($spec_result_set) && !$database->fetch_array($service_result_set)){
		redirect_to("it_guy_new_ui.php");
	}	

	$spec_result_set = $database->query($specialists_sql);
	$service_result_set = $database->query($service_sql);
?>

<?php include_layout_template('it_guy_header.php'); ?>

<div class="w3-container w3-section w3-card-2 property-form" id="prop-form">
	<h2><b><?php echo $healthyCenter->name;?> Information</b></h2>
	<h5 style="color: #595854;">Please Enter Your Details Below</h5>
	<hr style="border-color: black;" />
	<form action="edit.php" enctype="multipart/form-data" method="POST">
	  <fieldset id="spec" style="border-radius: 5px; border-color: black; padding-top: 20px; margin-bottom: 20px;">
	  	<legend>Specialists</legend>

	  		<?php
	  			$i = 1;
	  			while ($row = $database->fetch_array($spec_result_set)) {
			      echo "<div>";
			      echo "<input type='text' name='w_hour".$i."' value='".$row['working_hour']."' required=''> &nbsp; &nbsp;";
			      echo "<input type='text' name='spec".$i."' value='".$row['specialist']."' required=''>";
			      echo "<input type='hidden' name='hidden_spec".$i."' value='".$row['id']."'>";
			      echo "</div>";
			      $i++;
			    }

	  		?>

		</fieldset> 

		<fieldset id="spec" style="border-radius: 5px; border-color: black; padding-top: 20px; margin-bottom: 20px;">
	  	<legend>Service Price</legend>

	  		<?php
	  			$i = 1;
	  			while ($row = $database->fetch_array($service_result_set)) {
			      echo "<div>";
			      echo "<input type='text' name='service".$i."' value='".$row['service']."' required=''> &nbsp; &nbsp;";
			      echo "<input type='text' name='price".$i."' value='".$row['price']."' required=''>";
			      echo "<input type='hidden' name='hidden_service".$i."' value='".$row['id']."'>";
			      echo "</div>";
			      $i++;
			    }

	  		?>

		</fieldset> 
	  <div> 
	  <input type="submit" name="edit" value="Upload" class="w3-btn-block">
	  </div>
	</form>
</div>
<!-- property form END -->

<?php include_layout_template('admin_footer.php'); ?>

<script type="text/javascript">
	$("#prop-form div").addClass("property-form-div");
	$("#prop-form div input[type='text']").addClass("w3-right w3-border property-form-input");
	$("#prop-form div input[type='file']").addClass("w3-input property-form-input-img");
	$("#prop-form div input[type='email']").addClass("w3-right w3-border property-form-input");
	$("#prop-form div input[type='password']").addClass("w3-right w3-border property-form-input");
	$("#spec input").removeClass("w3-right property-form-input").addClass("Specialist");
</script>