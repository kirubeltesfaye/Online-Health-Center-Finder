<?php require_once("../../includes/initialize.php"); ?>

<?php

	if (isset($_GET['id'])) {
		$id = $_GET['id'];
		$user = Admin::find_by_id($id);
		$user->delete();
		redirect_to("doctors_ui.php");
	}

?>