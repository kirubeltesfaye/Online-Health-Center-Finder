<?php require_once("../../includes/initialize.php"); ?>
<?php

if(isset($_POST['submit'])){
	$records = [];
	$records["first_name"] = trim($_POST['firstname']);
	$records["last_name"] = trim($_POST['lastname']);
	$records["email"] = trim($_POST['email']);
	$records["password"] = trim($_POST['password']);
	$records["type"] = "admin";

	if($admin = Admin::make($records)){ // signed up successfuly
		$admin->create();
		redirect_to("sign_in_ui.php");
	} else { // sign up failed

	}

}

?>