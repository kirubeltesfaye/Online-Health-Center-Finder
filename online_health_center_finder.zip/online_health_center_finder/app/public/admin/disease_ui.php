<?php require_once("../../includes/initialize.php"); ?>

<?php

	if(!$session->is_logged_in()){
		redirect_to('sign_in_ui.php');	
	}

	if (isset($_POST["add_cate"])) {
		$disease_category = $_POST['disease_cate'];
		$records = [];
		$records["category_name"] = $disease_category;
		$disease_category_obj = DiseaseCategory::make($records);
		$disease_category_obj->create();
	}

?>

<?php include_layout_template('admin_header.php'); ?>

<div class="w3-container w3-card-2 w3-account account-view">
	<div class="w3-container w3-right w3-section" style="position: relative; top: 15px; right: 5px;">
	<form action="disease_ui.php" method="post">
		<input type="text" name="disease_cate" placeholder="Disease Category" required="">
		<input type="submit" name="add_cate" value="+Add" class="w3-btn w3-blue" />
	</form>
	</div>
	
	<h1 class="w3-container w3-section">Disease Categories</h1>
	<hr class="w3-border-black" />
	<?php

		$disease_cates = DiseaseCategory::find_all();

		for ($i=0; $i < count($disease_cates); $i++) { 
			echo "<div class='w3-container w3-section'>";
			echo "<span style='font-size: 18px; float: left;'>".$disease_cates[$i]->category_name."</span>";
			echo "<span style='float: right; width: 17.5%;'>";
			echo "<a href='edit_disease.php?id=".$disease_cates[$i]->id."' class='w3-btn w3-blue'>Edit</a>";
			echo " ";
			echo "<a href='delete_disease_category.php?id=".$disease_cates[$i]->id."' class='w3-btn w3-blue'>Delete</a>";
			echo "</span>";
			echo "</div>";
			echo "<hr />";
		}

	?>
</div>
	
<?php include_layout_template('admin_footer.php'); ?> 