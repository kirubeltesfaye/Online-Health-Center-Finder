<?php require_once("../../includes/initialize.php"); ?>

<?php

	if (isset($_GET['id'])) {
		$id = $_GET['id'];
		$user = healtyCenter::find_by_id($id);
		$user->delete();
		redirect_to("healty_center_control_ui.php");
	}

?>