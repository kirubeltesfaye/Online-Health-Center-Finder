<?php require_once("../../includes/initialize.php"); ?>

<?php
	if(isset($_POST['upload'])){
		$details = [];
		$details["name"] = $database->escape_value(trim($_POST['name']));
		$details["lat"] = $database->escape_value(trim($_POST['lat']));
		$details["lon"] = $database->escape_value(trim($_POST['lot']));
		$details["discription"] = $database->escape_value(trim($_POST['disc']));

		$upload_dir = "../images";
		$file_path = "";

		if($_FILES['file_upload']['tmp_name']){
			$tmp_file = $_FILES['file_upload']['tmp_name'];
			$target_file = basename($_FILES['file_upload']['name']);
			move_uploaded_file($tmp_file, $upload_dir."/".$target_file);
			$file_path .= $database->escape_value("images/".$target_file);
		}

		$details["img"] = $file_path;
		$healtyCenter = healtyCenter::make($details);
		$healtyCenter->create();

		$id = $healtyCenter->id;

		$records = [];
		$records["first_name"] = trim($_POST['first_name']);
		$records["last_name"] = trim($_POST['last_name']);
		$records["email"] = trim($_POST['email']);
		$records["password"] = trim($_POST['pass']);
		$records["type"] = "itGuy";
		$records["healthy_center_id"] = $id;

		if($admin = Admin::make($records)){ // signed up successfuly
			$admin->create();
			//redirect_to("doctors_ui.php");
		} else { // sign up failed

		}
		
		global $message;
		$message = "Healty Center Successfuly Added!";
		redirect_to("healty_center_control_ui.php");
	}
?>