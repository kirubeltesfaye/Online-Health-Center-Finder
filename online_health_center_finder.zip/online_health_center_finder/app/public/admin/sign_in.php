<?php require_once("../../includes/initialize.php"); 

if($session_admin->is_logged_in()){
	redirect_to("./profile_ui.php");
} 

if(isset($_POST['submit'])){ //not logged in
	$email = trim($_POST['email']);
	$password = trim($_POST['password']);

	$found_user = Admin::authenticate($email, $password);

	if($found_user){
		$session_admin->login($found_user);
		if($found_user->type == "admin"){
			redirect_to("./profile_ui.php");
		} else if ($found_user->type == "doctor"){
			redirect_to("../index.php");
		} else if ($found_user->type == "itGuy"){
			redirect_to("./it_guy_ui.php");
		}
	} else {
		$message = "Username/password combination is incorrect.";
	}

} else { // form is not submitted
	$username = "";
	$password = "";
	redirect_to("./sign_in_ui.php");
}

?>