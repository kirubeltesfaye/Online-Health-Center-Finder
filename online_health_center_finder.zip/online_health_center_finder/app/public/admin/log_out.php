<?php require_once("../../includes/initialize.php"); 

if($session_admin->is_logged_in()){
	$session_admin->logout();
	redirect_to("./sign_in_ui.php");
} else {
	redirect_to("./sign_in_ui.php");
}