<?php require_once("../../includes/initialize.php"); ?>

<?php

	if(!$session->is_logged_in()){
		redirect_to('sign_in_ui.php');	
	}

	if (isset($_GET['id'])) {
		$id = $_GET['id']; 
	}

?>

<?php include_layout_template('admin_header.php'); ?>

<div class="w3-container w3-section w3-card-2 property-form" id="prop-form">
	<h2><b>Disease information</b></h2>
	<h5 style="color: #595854;">Please Enter Your Details Below</h5>
	<hr style="border-color: black;" />
	<form action="add_disease.php" enctype="multipart/form-data" method="POST">
	  <input type="hidden" name="MAX_FILE_SIZE" value="1000000" />
	  <input type="hidden" name="disease_category_id" value="<?php echo $id;?>" />
	  <div><span><b>Disease Name: </b></span>
	  <input type="text" name="disease_name" placeholder="Disease Name" required="">
	  </div>
	  <div><span style="float: left;"><b>Description: </b></span>
	  <textarea placeholder="Description" cols="10" rows="4" class="w3-right w3-border property-form-input"
	  name="disease_dise"></textarea>
	  </div> <br /> <br /> <br /> <br />
		<p>Images</p>
	  <div>
	  <input type="file" name="file_upload" required="" />
	  </div>
	  <div> 
	  <input type="submit" name="add_disease" value="Add" class="w3-btn-block">
	  </div>
	</form>
</div>
<!-- property form END -->

<?php include_layout_template('admin_footer.php'); ?>

<script type="text/javascript">
	$("#prop-form div").addClass("property-form-div");
	$("#prop-form div input[type='text']").addClass("w3-right w3-border property-form-input");
	$("#prop-form div input[type='file']").addClass("w3-input property-form-input-img");
	$("#prop-form div input[type='email']").addClass("w3-right w3-border property-form-input");
	$("#prop-form div input[type='password']").addClass("w3-right w3-border property-form-input");
	$("#spec input").removeClass("w3-right property-form-input").addClass("Specialist");
</script>
