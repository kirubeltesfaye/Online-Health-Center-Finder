<?php require_once("../../includes/initialize.php"); ?>

<?php

	$user_id = $session->user_id;
	$user = Admin::find_by_id($user_id);
	$id = $user->healthy_center_id;	

	if (isset($_POST['edit'])) {
		$spec_details = [];
		$spec_details["w_hour1"] = $database->escape_value(trim($_POST['w_hour1']));
		$spec_details["spec1"] = $database->escape_value(trim($_POST['spec1']));
		$spec_details["hidden_spec1"] = $database->escape_value(trim($_POST['hidden_spec1']));
		$spec_details["w_hour2"] = $database->escape_value(trim($_POST['w_hour2']));
		$spec_details["spec2"] = $database->escape_value(trim($_POST['spec2']));
		$spec_details["hidden_spec2"] = $database->escape_value(trim($_POST['hidden_spec2']));
		$spec_details["w_hour3"] = $database->escape_value(trim($_POST['w_hour3']));
		$spec_details["spec3"] = $database->escape_value(trim($_POST['spec3']));
		$spec_details["hidden_spec3"] = $database->escape_value(trim($_POST['hidden_spec3']));
		$spec_details["w_hour4"] = $database->escape_value(trim($_POST['w_hour4']));
		$spec_details["spec4"] = $database->escape_value(trim($_POST['spec4']));
		$spec_details["hidden_spec4"] = $database->escape_value(trim($_POST['hidden_spec4']));

		$service_details = [];
		$service_details["service1"] = $database->escape_value(trim($_POST['service1']));
		$service_details["price1"] = $database->escape_value(trim($_POST['price1']));
		$spec_details["hidden_service1"] = $database->escape_value(trim($_POST['hidden_service1']));
		$service_details["service2"] = $database->escape_value(trim($_POST['service2']));
		$service_details["price2"] = $database->escape_value(trim($_POST['price2']));
		$spec_details["hidden_service2"] = $database->escape_value(trim($_POST['hidden_service2']));
		$service_details["service3"] = $database->escape_value(trim($_POST['service3']));
		$service_details["price3"] = $database->escape_value(trim($_POST['price3']));
		$spec_details["hidden_service3"] = $database->escape_value(trim($_POST['hidden_service3']));
		$service_details["service4"] = $database->escape_value(trim($_POST['service4']));
		$service_details["price4"] = $database->escape_value(trim($_POST['price4']));
		$spec_details["hidden_service4"] = $database->escape_value(trim($_POST['hidden_service4']));

		for ($i=1; $i <= 4; $i++) { 
			$w_h = $spec_details['w_hour'.$i];
			$spe = $spec_details['spec'.$i];
			$spe_id = $spec_details['hidden_spec'.$i];

			$ser = $service_details['service'.$i];
			$pri = $service_details['price'.$i];
			$ser_id = $spec_details['hidden_service'.$i];

			$sql = "UPDATE specialists SET working_hour='{$w_h}', specialist='{$spe}' WHERE id={$spe_id}";
			$database->query($sql);

			$sql = "UPDATE service_price SET service='{$ser}', price='{$pri}' WHERE id={$ser_id}";
			$database->query($sql);
		}

		redirect_to('it_guy_ui.php');	
	}

?>