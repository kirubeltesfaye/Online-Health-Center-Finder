<?php require_once("../../includes/initialize.php"); ?>

<?php
	if($session_admin->is_logged_in()){
		$admin_id = $session_admin->user_id;
		$currentUser = Admin::find_by_id($admin_id);
	} else {
		redirect_to("./sign_in_ui.php");
	}
?>

<?php include_layout_template('admin_header.php'); ?>

<!-- profile page START -->
<div class="w3-container profile">
	<!-- side nav START -->
	<div class="left-nav">
		<!-- profile link -->
		<a href="javascript: void(0)" onclick="showProfile()" class="w3-btn-block w3-left-align w3-white w3-border-bottom w3-hover-blue">Profile</a>
		<a href="log_out.php" class="w3-btn-block w3-left-align w3-white w3-border-bottom w3-hover-blue">Log Out</a>
	</div>
	<!-- side nav END -->
	<!-- nav view START -->
	<div class="nav-body w3-border-left" id="nav-body">
		<p>nav body</p>
	</div>
	<!-- nav view END -->
</div>

<!-- profile body START -->
<div id="profile-body" style="display: none;">
	<div class="w3-container"> 
		<div class="w3-container w3-border-bottom"> <!--for profile pic-->
			<h3>Profile Picture</h3>
			<div class="w3-card w3-border-white profile-pic">
				<img src="../images/avatar.png" alt="Profile" width="20%" height="20%">
			</div>
		</div>
		<div class="w3-container w3-border-bottom"> <!--for user name-->
 			<h3>User Name</h3>
 			<P><?php echo $currentUser->full_name();?></P>
		</div> 
		<div class="w3-container w3-border-bottom"> <!--for email-->
			<h3>Email</h3>
 			<P><?php echo $currentUser->email;?></P>
		</div>
	</div>
</div>
<!-- profile body END -->

<!-- profile page END -->

<?php include_layout_template('admin_footer.php'); ?> 
<script type="text/javascript">
	var navBody = $("#nav-body");
	var profileBody = $("#profile-body").html();
	navBody.html(profileBody);

	function myAccFunc() {
	    var x = document.getElementById("demoAcc");
	    if (x.className.indexOf("w3-show") == -1) {
	        x.className += " w3-show";
	        x.previousElementSibling.className += " w3-green";
	    } else { 
	        x.className = x.className.replace(" w3-show", "");
	        x.previousElementSibling.className = 
	        x.previousElementSibling.className.replace(" w3-green", "");
	    }
	}
	var navBody = $("#nav-body");
	function showProfile() {
		var profileBody = $("#profile-body").html();
		navBody.html(profileBody);
	}

</script>