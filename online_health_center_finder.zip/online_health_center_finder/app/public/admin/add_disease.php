<?php require_once("../../includes/initialize.php"); ?>

<?php


	if(isset($_POST['add_disease'])){
		$id = $_POST['disease_category_id'];
		$records = [];
		$records["category_id"] = trim($_POST['disease_category_id']);
		$records["name"] = trim($_POST['disease_name']);
		$records["discription"] = trim($_POST['disease_dise']);

		$upload_dir = "../images";
		$file_path = "";

		if($_FILES['file_upload']['tmp_name']){
			$tmp_file = $_FILES['file_upload']['tmp_name'];
			$target_file = basename($_FILES['file_upload']['name']);
			move_uploaded_file($tmp_file, $upload_dir."/".$target_file);
			$file_path .= $database->escape_value("images/".$target_file);
		}

		$records['img'] = $file_path;

		// print_r($records);

		echo $id;

		if($disease = Disease::make($records)){ // signed up successfuly
			echo "string";
			$disease->create();
			redirect_to("edit_disease.php?id=".$id."");	
		}
	}

	// if(!$session->is_logged_in()){
	// 	redirect_to('sign_in_ui.php');	
	// }

?>
