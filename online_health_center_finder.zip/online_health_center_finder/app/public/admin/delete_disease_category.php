<?php require_once("../../includes/initialize.php"); ?>

<?php

	if (isset($_GET['id'])) {
		$id = $_GET['id'];
		$disease_category = DiseaseCategory::find_by_id($id);
		$diseases = Disease::find_by_cate_id($id);
		$disease_category->delete();
		if($diseases){
			for ($i=0; $i < count($diseases); $i++) { 
				$diseases[$i]->delete();
			}	
		}
		redirect_to("disease_ui.php");
	}

?>