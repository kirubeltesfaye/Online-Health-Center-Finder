<?php require_once("../../includes/initialize.php"); ?>


<?php

	$user_id = $session->user_id;
	$user = Admin::find_by_id($user_id);
	$id = $user->healthy_center_id;	

	if (isset($_POST['add'])) {
		$spec_details = [];
		$spec_details["w_hour1"] = $database->escape_value(trim($_POST['w_hour1']));
		$spec_details["spec1"] = $database->escape_value(trim($_POST['spec1']));
		$spec_details["w_hour2"] = $database->escape_value(trim($_POST['w_hour2']));
		$spec_details["spec2"] = $database->escape_value(trim($_POST['spec2']));
		$spec_details["w_hour3"] = $database->escape_value(trim($_POST['w_hour3']));
		$spec_details["spec3"] = $database->escape_value(trim($_POST['spec3']));
		$spec_details["w_hour4"] = $database->escape_value(trim($_POST['w_hour4']));
		$spec_details["spec4"] = $database->escape_value(trim($_POST['spec4']));

		$service_details = [];
		$service_details["service1"] = $database->escape_value(trim($_POST['service1']));
		$service_details["price1"] = $database->escape_value(trim($_POST['price1']));
		$service_details["service2"] = $database->escape_value(trim($_POST['service2']));
		$service_details["price2"] = $database->escape_value(trim($_POST['price2']));
		$service_details["service3"] = $database->escape_value(trim($_POST['service3']));
		$service_details["price3"] = $database->escape_value(trim($_POST['price3']));
		$service_details["service4"] = $database->escape_value(trim($_POST['service4']));
		$service_details["price4"] = $database->escape_value(trim($_POST['price4']));

		for ($i=1; $i <= 4; $i++) { 
			$w_h = $spec_details['w_hour'.$i];
			$spe = $spec_details['spec'.$i];
			$ser = $service_details['service'.$i];
			$pri = $service_details['price'.$i];
			$sql = "INSERT INTO specialists (working_hour, specialist, healthy_center_id) VALUES 
			( '{$w_h}', '{$spe}', {$id})";
			$database->query($sql);
			$sql = "INSERT INTO service_price (service, price, healthy_center_id) VALUES 
			( '{$ser}', {$pri}, {$id})";
			$database->query($sql);
		}

		redirect_to('it_guy_ui.php');	
	}

?>

<?php include_layout_template('it_guy_header.php'); ?>

<div class="w3-container w3-section w3-card-2 property-form" id="prop-form">
	<h2><b>Healty Center Information</b></h2>
	<h5 style="color: #595854;">Please Enter Your Details Below</h5>
	<hr style="border-color: black;" />
	<form action="it_guy_new_ui.php" enctype="multipart/form-data" method="POST">
	  <fieldset id="spec" style="border-radius: 5px; border-color: black; padding-top: 20px; margin-bottom: 20px;">
	  	<legend>Specialists</legend>
	  	<div>
		  	<input type="text" name="w_hour1" placeholder="Working Hour" required=""> &nbsp; &nbsp;	
		  	<input type="text" name="spec1" placeholder="On Duty Specialist" required="">
			</div>
			<div>
			  	<input type="text" name="w_hour2" placeholder="Working Hour" required=""> &nbsp; &nbsp;
			  	<input type="text" name="spec2" placeholder="On Duty Specialist" required="">
			</div>
			<div>
			  	<input type="text" name="w_hour3" placeholder="Working Hour" required=""> &nbsp; &nbsp;	
			  	<input type="text" name="spec3" placeholder="On Duty Specialist" required="">
			</div>
			<div>
			  	<input type="text" name="w_hour4" placeholder="Working Hour" required=""> &nbsp; &nbsp;	
			  	<input type="text" name="spec4" placeholder="On Duty Specialist" required="">
			</div>
		</fieldset> 

		<fieldset id="spec" style="border-radius: 5px; border-color: black; padding-top: 20px; margin-bottom: 20px;">
	  	<legend>Service Price</legend>
	  	<div>
		  	<input type="text" name="service1" placeholder="Service" required=""> &nbsp; &nbsp;	
		  	<input type="text" name="price1" placeholder="Price" required="">
			</div>
			<div>
			  	<input type="text" name="service2" placeholder="Service" required=""> &nbsp; &nbsp;
			  	<input type="text" name="price2" placeholder="Price" required="">
			</div>
			<div>
			  	<input type="text" name="service3" placeholder="Service" required=""> &nbsp; &nbsp;	
			  	<input type="text" name="price3" placeholder="Price" required="">
			</div>
			<div>
			  	<input type="text" name="service4" placeholder="Service" required=""> &nbsp; &nbsp;	
			  	<input type="text" name="price4" placeholder="Price" required="">
			</div>
		</fieldset> 
	  <div> 
	  <input type="submit" name="add" value="Upload" class="w3-btn-block">
	  </div>
	</form>
</div>
<!-- property form END -->

<?php include_layout_template('admin_footer.php'); ?>

<script type="text/javascript">
	$("#prop-form div").addClass("property-form-div");
	$("#prop-form div input[type='text']").addClass("w3-right w3-border property-form-input");
	$("#prop-form div input[type='file']").addClass("w3-input property-form-input-img");
	$("#prop-form div input[type='email']").addClass("w3-right w3-border property-form-input");
	$("#prop-form div input[type='password']").addClass("w3-right w3-border property-form-input");
	$("#spec input").removeClass("w3-right property-form-input").addClass("Specialist");
</script>	