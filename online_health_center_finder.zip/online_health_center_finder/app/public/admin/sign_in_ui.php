<?php require_once("../../includes/initialize.php"); ?>

<?php include_layout_template('admin_header.php'); ?>

<?php
	if($session_admin->is_logged_in()){
		redirect_to("./profile_ui.php");
	} 
?>

<!-- START sign in form container -->
<div class="w3-container sign-in-body-container" style="height: 550px;">
	<div class="w3-container darken-background">
		<span class="w3-jumbo slogan">
			<b>The Best Way <br />
			To Live <br />
			Healthy</b>
		</span>
		<div class="w3-container w3-padding-large sign_form">

			<form action="sign_in.php" method="post">
				<input type="email" name="email" placeholder="Email" class="w3-input w3-border w3-section" required="required">
				<input type="password" name="password" placeholder="Password" class="w3-input w3-border w3-section" required="required">
				<input type="submit" value="Sign In" name="submit" class="w3-btn-block w3-section">
			</form>
			<div>
				<a href="sign_up_ui.php" class="sign-up-link w3-border-left w3-border-silver"></a>
			</div>
		</div>
	</div>
</div>
<!-- END sign in form container -->

<?php include_layout_template('admin_footer.php'); ?>