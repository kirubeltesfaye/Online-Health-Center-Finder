<?php require_once("../../includes/initialize.php"); ?>

<?php include_layout_template('admin_header.php'); ?>

<!-- START sign up form container -->
<div class="w3-container sign-up-body-container">
	<div class="w3-container darken-background">
		<span class="w3-jumbo slogan">
			<b>The Best Way <br />
			To Live <br />
			Healthy</b>
		</span>
		<div class="w3-container w3-padding-large sign_form">
		
			<form action="sign_up.php" method="post">
				<input type="text" name="firstname" placeholder="First Name" class="w3-input w3-border w3-section" required="required">
				<input type="text" name="lastname" placeholder="Last Name" class="w3-input w3-border w3-section" required="required">
				<input type="email" name="email" placeholder="Email" class="w3-input w3-border w3-section" required="required">
				<input type="password" name="password" placeholder="Password" class="w3-input w3-border w3-section" required="required">
				<input type="password" name="repassword" placeholder="Re-Password" class="w3-input w3-border w3-section" required="required">
				<input type="submit" value="Sign Up" name="submit" class="w3-btn-block w3-section">
			</form>
			
		</div>
	</div>
</div>
<!-- END sign up form container -->

<?php include_layout_template('admin_footer.php'); ?>