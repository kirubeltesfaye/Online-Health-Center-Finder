<?php require_once("../../includes/initialize.php"); ?>

<?php

	if (isset($_GET['id'])) {
		$id = $_GET['id'];
		$disease = Disease::find_by_id($id);
		$cate_id = $disease->category_id;
		$disease->delete();
		redirect_to("edit_disease.php?id=".$cate_id);
	}

?>