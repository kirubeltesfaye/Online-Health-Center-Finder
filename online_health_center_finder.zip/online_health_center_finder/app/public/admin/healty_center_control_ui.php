<?php require_once("../../includes/initialize.php"); ?>

<?php

	if(!$session->is_logged_in()){
		redirect_to('sign_in_ui.php');	
	}

?>

<?php include_layout_template('admin_header.php'); ?>

<div class="w3-container w3-card-2 w3-account account-view">
	<div class="w3-container w3-right w3-section" style="position: relative; top: 15px; right: 5px;">
		<a href="add_ui.php" class="w3-btn w3-blue">+ Add</a>
	</div>
	
	<h1 class="w3-container w3-section">Healthy Center</h1>
	<hr class="w3-border-black" />

	<?php

		$healty_centers = healtyCenter::find_all();

		for ($i=0; $i < count($healty_centers); $i++) { 
			echo "<div class='w3-container w3-section'>";
			echo "<span style='font-size: 18px; float: left;'>".$healty_centers[$i]->name."</span>";
			echo "<span style='float: right; width: 10%;'>";
			echo "<a href='delete.php?id=".$healty_centers[$i]->id."' class='w3-btn w3-blue'>Delete</a>";
			echo "</span>";
			echo "</div>";
			echo "<hr />";
		}

	?>
</div>
	
<?php include_layout_template('admin_footer.php'); ?> 