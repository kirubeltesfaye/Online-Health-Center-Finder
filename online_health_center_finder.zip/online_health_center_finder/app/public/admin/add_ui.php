<?php require_once("../../includes/initialize.php"); ?>

<?php

	if(!$session->is_logged_in()){
		redirect_to('sign_in_ui.php');	
	}

?>

<?php include_layout_template('admin_header.php'); ?>

<div class="w3-container w3-section w3-card-2 property-form" id="prop-form">
	<h2><b>Healty Center Information</b></h2>
	<h5 style="color: #595854;">Please Enter Your Details Below</h5>
	<hr style="border-color: black;" />
	<form action="add.php" enctype="multipart/form-data" method="POST">
	  <input type="hidden" name="MAX_FILE_SIZE" value="1000000" />
	  <div><span><b>Healthy Center Name: </b></span>
	  <input type="text" name="name" placeholder="Healthy Center Name" required="">
	  </div>
	  <div><span><b>Latitude Loaction: </b></span>
	  <input type="text" name="lat" placeholder="Latitude" required="">
	  </div>
	  <div><span><b>Longitude Loaction: </b></span>
	  <input type="text" name="lot" placeholder="Longitude" required="">
	  </div>
	  <div><span style="float: left;"><b>Description: </b></span>
	  <textarea placeholder="Description" cols="10" rows="4" class="w3-right w3-border property-form-input"
	  name="disc"></textarea>
	  </div> <br /> <br /> <br /> <br />
		<p>Images</p>
	  <div>
	  <input type="file" name="file_upload" required="" />
	  </div>
	  <fieldset class="w3-section" style="border-radius: 3px; border-color: black;">
		  <legend>IT Guy</legend>
		  <div><span><b>First Name: </b></span>
		  <input type="text" name="first_name" placeholder="First Name" required="">
		  </div>
		  <div><span><b>Last Name: </b></span>
		  <input type="text" name="last_name" placeholder="Last Name" required="">
		  </div>
		  <div><span><b>Email: </b></span>
		  <input type="email" name="email" placeholder="Email" required="">
		  </div>
		  <div><span><b>Password: </b></span>
		  <input type="password" name="pass" placeholder="Password" required="">
		  </div>
		  <div><span><b>Re-Password: </b></span>
		  <input type="password" name="re_pass" placeholder="Re-Password" required="">
		  </div>
	  </fieldset>
	  <div> 
	  <input type="submit" name="upload" value="Upload" class="w3-btn-block">
	  </div>
	</form>
</div>
<!-- property form END -->

<?php include_layout_template('admin_footer.php'); ?>

<script type="text/javascript">
	$("#prop-form div").addClass("property-form-div");
	$("#prop-form div input[type='text']").addClass("w3-right w3-border property-form-input");
	$("#prop-form div input[type='file']").addClass("w3-input property-form-input-img");
	$("#prop-form div input[type='email']").addClass("w3-right w3-border property-form-input");
	$("#prop-form div input[type='password']").addClass("w3-right w3-border property-form-input");
	$("#spec input").removeClass("w3-right property-form-input").addClass("Specialist");
</script>
