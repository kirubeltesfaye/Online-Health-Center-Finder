$(document).ready(function() {

	//current page file name
	var file_name = document.location.href.match(/[^\/]+$/)[0];
	var logo_hat = $("#logo-hat");
	if(file_name == "sign_up_ui.php" || file_name == "sign_in_ui.php" || file_name == "profile_ui.php"){
		removeTopBarHeader();
		logo_hat.css("top", "5%");
	} else {
		logo_hat.css("top", "32%");
	}

	// start body element after fixed header 
	var header_height = $("#header").height();
	$("#clone_header").height(header_height);

	// remove top small bar header for sign in and sign up pages
	function removeTopBarHeader(){
		$("#small_header").css("display", "none");
	}

});
