<?php require_once("../includes/initialize.php"); 

if(isset($_POST["post"])){

	$post_body = $_POST['post_body'];
	$user_id = $session->user_id;
	$author = Admin::find_by_id($user_id);

	$records = [];
	$records["author"] = $author->full_name();
	$records["body"] = $post_body; 

	$post = Post::make($records);
	echo $post->created_date;
	$post->create();

	redirect_to("index.php");
}

?>