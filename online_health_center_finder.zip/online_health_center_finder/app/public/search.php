<?php require_once("../includes/initialize.php"); ?>

<?php

	if (isset($_GET['search'])) {
		$content = $_GET['search_body'];

		$sql = "SELECT * FROM healthy_center WHERE name LIKE '%".$content."' OR name LIKE '%".$content."%' OR name LIKE '".$content."%'";

		$sql2 = "SELECT * FROM disease WHERE name LIKE '%".$content."' OR name LIKE '%".$content."%' OR name LIKE '".$content."%'";

		$result = healtyCenter::find_by_sql($sql);
		$result2 = Disease::find_by_sql($sql2); 

	}

?>

<?php include_layout_template('header.php'); ?>

<!-- grid view START -->
<div class="w3-container w3-card-2 w3-section map">
	<div class="w3-container">
		<?php 
			if($result){
				echo "<h2>Healthy Center</h2>";
				echo "<hr style='border-color: black;' />";
				for ($i=0; $i < count($result); $i++) { 
					echo "<div>";
					echo "<h2><a href='healthy_care_ui.php?id=".$result[$i]->id."'>".$result[$i]->name."</a></h2>";
					echo "<p>".$result[$i]->discription."</p>";
					echo "</div>";
					echo "<hr />";
				}
			}
		?>
	</div>
	<div class="w3-container">
		<?php
			if($result2){
				echo "<h2>Dieases</h2>";
				echo "<hr style='border-color: black;' />";
				for ($i=0; $i < count($result2); $i++) { 
					echo "<div>";
					echo "<h2><a href=''>".$result2[$i]->name."</a></h2>";
					echo "<p>".$result2[$i]->discription."</p>";
					echo "</div>";
					echo "<hr />";
				}
			}
		?>
	</div>
</div>

<!-- grid view END -->

<?php include_layout_template('footer.php'); ?>