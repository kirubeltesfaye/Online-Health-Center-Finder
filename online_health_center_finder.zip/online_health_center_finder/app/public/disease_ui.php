<?php require_once("../includes/initialize.php"); ?>

<?php

	if(isset($_GET['id'])){
		$id = $_GET['id'];
		$disease_cate = DiseaseCategory::find_by_id($id);
	}

?>

<?php include_layout_template('header.php'); ?>

<!-- real estate START -->
<div class="w3-container w3-section w3-card-4 real-estate-ui">
	<h1 class="w3-center w3-border-bottom"><?php echo $disease_cate->category_name;?></h1>
	
	<?php

		$diseases = Disease::find_by_cate_id($id);

		if($diseases){
			for ($i=0; $i < count($diseases); $i++) { 
				echo "<div class='w3-contaner w3-section' style='padding: 20px; overflow: auto'>";
				echo "<h3>".$diseases[$i]->name."</h3>";
				echo "<p><img src='{$diseases[$i]->img}' alt='Healty Center' height='150' width='150' align='left'
					  style='padding-right: 10px;''>{$diseases[$i]->discription}</p>";
				echo "</div>";

				// $services = "SELECT * FROM service_price WHERE =".$id;
				// $rec_healthy_center = 
			}

		} else {

		}

	?>

	<!-- map END -->
</div>
<!-- real estate END -->

<?php include_layout_template('footer.php'); ?>
