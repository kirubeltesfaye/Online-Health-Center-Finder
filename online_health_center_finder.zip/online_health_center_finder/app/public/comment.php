<?php require_once("../includes/initialize.php"); 

if(isset($_POST["comment"])){

	$comment_body = $_POST['comment_body'];
	$post_id = $_POST['hidden_id'];

	$post = Comment::make($post_id, $comment_body);
	echo $post->created_date;
	$post->create();

	redirect_to("index.php");
}

?>