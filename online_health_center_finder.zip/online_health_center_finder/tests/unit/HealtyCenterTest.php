<?php

class HealtyCenterTest extends \PHPUnit_Framework_TestCase
{
	protected $details;

	public function setUp(){
		$this->details = array(
			array('id' => 0, 
				'name' => 'name one', 
				'img' => 'healthyImgOne', 
				'discription' => 'healthyImg discription', 
				'lat' => 43.325, 
				'lon' => 24.123),
			array('id' => 1, 
				'name' => 'name two', 
				'img' => 'healthyImgTwo', 
				'discription' => 'healthyImg discription', 
				'lat' => 62.323, 
				'lon' => 22.445)
		);
	}	

	/** @test */
    public function make_function_should_return_a_HealtyCenter_object(){

        $HealtyCenter = \App\Includes\HealtyCenter::make($this->details[0]);

        $this->assertInstanceOF(\App\Includes\HealtyCenter::class, $HealtyCenter);
        $this->assertEquals($HealtyCenter->name, 'name one');
    }

    /** @test */
    public function find_all_function_should_return_all_HealtyCenters(){

        $HealtyCenter = \Mockery::mock('HealtyCenter');
        $HealtyCenter->shouldReceive('find_all')->withNoArgs()->andReturnUsing(function () {
            $HealtyCenters = array();
            for ($i=0; $i < count($this->details); $i++) { 
            	array_push($HealtyCenters, \App\Includes\HealtyCenter::make($this->details[$i]));
            }
            return $HealtyCenters;
        });

        $HealtyCenters = $HealtyCenter->find_all();

        $this->assertInternalType('array', $HealtyCenters);
        $this->assertInstanceOF(\App\Includes\HealtyCenter::class, $HealtyCenters[0]);
    }

    /** @test */
    public function find_by_id_function_should_return_a_HealtyCenter_with_id(){

        $HealtyCenter = \Mockery::mock('HealtyCenter');
        $HealtyCenter->shouldReceive('find_by_id')->andReturnUsing(function ($id) {
            for ($i=0; $i < count($this->details); $i++) { 
				if($this->details[$i]['id'] == $id){
					return \App\Includes\HealtyCenter::make($this->details[$i]);
				}
			}
			return false;
        });

        $mockedResultHealtyCenter = $HealtyCenter->find_by_id(0);

        $this->assertInstanceOF(\App\Includes\HealtyCenter::class, $mockedResultHealtyCenter);
        $this->assertEquals($mockedResultHealtyCenter->id, 0);
    }

    /** @test */
    public function instantiate_function_should_return_a_HealtyCenter_instance(){

    	$HealtyCenter = \App\Includes\HealtyCenter::instantiate($this->details[0]);

    	$this->assertInstanceOF(\App\Includes\HealtyCenter::class, $HealtyCenter);
    	$this->assertEquals($HealtyCenter->id, 0);
    	$this->assertEquals($HealtyCenter->name, 'name one');
	}

	/** @test */
	public function has_attribute_function_should_return_true_if_HealtyCenter_has_an_attribute(){

		$HealtyCenter = new \App\Includes\HealtyCenter();

		$this->assertTrue($HealtyCenter->has_attribute("id"));
		$this->assertTrue($HealtyCenter->has_attribute("name"));
		$this->assertFalse($HealtyCenter->has_attribute("full_name"));
	}

	/** @test */
	public function attributes_function_should_return_array_of_attributes(){

		$HealtyCenter = \App\Includes\HealtyCenter::make($this->details[1]);
		$HealtyCenter_attributes = $HealtyCenter->attributes();

		$this->assertInternalType('array', $HealtyCenter_attributes);
		$this->assertTrue(array_key_exists("id", $HealtyCenter_attributes));
		$this->assertFalse(array_key_exists("created_date", $HealtyCenter_attributes));
		$this->assertEquals($HealtyCenter_attributes['id'], 1);
	}

	/** @test */
	public function create_function_should_return_true_when_new_HealtyCenter_created(){

		$HealtyCenter = \Mockery::mock('\App\Includes\HealtyCenter[create]');
		$HealtyCenter->shouldReceive('create')->andReturnUsing(function () {
			$db_fields = array('id', 'name', 'img', 'discription', 'lat', 'lon');
			$attributes = array();
			$db_array = array();

			foreach($db_fields as $field) {
				if(property_exists(\App\Includes\HealtyCenter::class, $field)) {
					$attributes[$field] = $this->details[1][$field];
				}
			}

			$db_array[0] = array();
			foreach ($attributes as $key => $value) {
				$db_array[0][$key] = $value;	
			}

			if($db_array[0]["id"] == $attributes['id']){
				return true;
			} else {	
				return false;
			}
		});

		foreach ($this->details[1] as $key => $value) {
			$HealtyCenter->$key = $value;
		}

		$createStatus = $HealtyCenter->create();

		$this->assertTrue($createStatus);
	}

	/** @test */
	public function update_function_should_return_true_if_HealtyCenter_has_updated(){

		$HealtyCenter = \Mockery::mock('\App\Includes\HealtyCenter[update]');
		$HealtyCenter->shouldReceive('update')->andReturnUsing(function () {
			$db_array = array(
					$this->details[0]
				);

			$new_array = $this->details[0];
			$new_array['name'] = 'new health name';

			$db_array[$new_array['id']] = $new_array;

			if($db_array[$new_array['id']] == $new_array){
				return true;
			} else {	
				return false;
			}
		});
		$updateStatus = $HealtyCenter->update();

		$this->assertTrue($updateStatus);
	}

	/** @test */
	public function delete_function_should_return_true_if_HealtyCenter_has_deleted(){

		$HealtyCenter = \Mockery::mock('\App\Includes\HealtyCenter[delete]');
		$HealtyCenter->shouldReceive('delete')->andReturnUsing(function () {
			$db_array = array(
					$this->details[1]
				);

			$db_array[0] = null;

			if($db_array[0] == null){
				return true;
			} else {	
				return false;
			}
		});
		$deleteStatus = $HealtyCenter->delete();

		$this->assertTrue($deleteStatus);
	}
}