<?php

class AdminTest extends \PHPUnit_Framework_TestCase
{
	protected $details;

	public function setUp(){
		$this->details = array(
			array('id' => 0,
						'email' => 'test@test.com', 
    					'password' => 'testPass', 
    					'first_name' => 'testFirst', 
    					'last_name' => 'testLast', 
    					'type' => 'admin', 
    					'healthy_center_id' => 0),
			array('id' => 1,
						'email' => 'doctor@test.com', 
    					'password' => 'testDoctorPass', 
    					'first_name' => 'testFirstDoctor', 
    					'last_name' => 'testLastDoctor', 
    					'type' => 'doctor', 
    					'healthy_center_id' => 4)
		);
	}	

	/** @test */
    public function make_function_should_return_a_admin_object(){

        $admin = \App\Includes\Admin::make($this->details[0]);

        $this->assertInstanceOF(\App\Includes\Admin::class, $admin);
        $this->assertEquals($admin->email, 'test@test.com');
        $this->assertEquals($admin->type, 'admin');
    }

    /** @test */
    public function full_name_should_return_full_name_if_admin(){

    	$admin = \App\Includes\Admin::make($this->details[0]);

    	$this->assertEquals($admin->full_name(), 'testFirst testLast');
    }

    /** @test */
    public function authenticate_should_return_admin_or_false_if_admin_doesnt_exist(){

    	$admin = \Mockery::mock('\App\Includes\Admin[authenticate]');
		$admin->shouldReceive('authenticate')->andReturnUsing(function ($email, $password) {
			for ($i=0; $i < count($this->details); $i++) { 
				if($this->details[$i]['email'] == $email && 
					$this->details[$i]['password'] == $password){
					return \App\Includes\Admin::make($this->details[$i]);
				}
			}
			return false;
		});

		$authAdmin = $admin->authenticate("test@test.com", "testPass");

		$this->assertInstanceOF(\App\Includes\Admin::class, $authAdmin);
		$this->assertEquals($authAdmin->email, 'test@test.com');
        $this->assertEquals($authAdmin->type, 'admin');
    }

    /** @test */
    public function find_all_function_should_return_all_admins_doctors_itGuys(){

        $admin = \Mockery::mock('Admin');
        $admin->shouldReceive('find_all')->withNoArgs()->andReturnUsing(function () {
            $ReturnAdmin = \App\Includes\Admin::make($this->details[0]);
            return array($ReturnAdmin);
        });

        $admins = $admin->find_all();

        $this->assertInternalType('array', $admins);
        $this->assertInstanceOF(\App\Includes\Admin::class, $admins[0]);
        $this->assertEquals($admins[0]->last_name, 'testLast');
    }

    /** @test */
    public function find_all_admins_function_should_return_all_admin(){

        $admin = \Mockery::mock('Admin');
        $admin->shouldReceive('find_all_admins')->andReturnUsing(function () {
            $admins = array();
            for ($i=0; $i < count($this->details); $i++) { 
				if($this->details[$i]['type'] == 'admin'){
					array_push($admins, \App\Includes\Admin::make($this->details[$i]));
				}
			}
			return $admins;
        });

        $mockedResultadmin = $admin->find_all_admins();

        $this->assertInternalType('array', $mockedResultadmin);
        $this->assertInstanceOF(\App\Includes\Admin::class, $mockedResultadmin[0]);
        $this->assertEquals($mockedResultadmin[0]->type, 'admin');
    }

    /** @test */
    public function find_by_id_function_should_return_a_admin_with_id(){

        $admin = \Mockery::mock('Admin');
        $admin->shouldReceive('find_by_id')->andReturnUsing(function ($id) {
            for ($i=0; $i < count($this->details); $i++) { 
				if($this->details[$i]['id'] == $id){
					return \App\Includes\Admin::make($this->details[$i]);
				}
			}
			return false;
        });

        $mockedResultadmin = $admin->find_by_id(0);

        $this->assertInstanceOF(\App\Includes\Admin::class, $mockedResultadmin);
        $this->assertEquals($mockedResultadmin->id, 0);
    }

    /** @test */
    public function instantiate_function_should_return_a_admin_instance(){

    	$admin = \App\Includes\Admin::instantiate($this->details[0]);

    	$this->assertInstanceOF(\App\Includes\Admin::class, $admin);
    	$this->assertEquals($admin->id, 0);
    	$this->assertEquals($admin->email, 'test@test.com');
	}

	/** @test */
	public function has_attribute_function_should_return_true_if_admin_has_an_attribute(){

		$admin = new \App\Includes\Admin();

		$this->assertTrue($admin->has_attribute("id"));
		$this->assertTrue($admin->has_attribute("email"));
		$this->assertFalse($admin->has_attribute("name"));
	}

	/** @test */
	public function attributes_function_should_return_array_of_attributes(){

		$admin = \App\Includes\Admin::make($this->details[1]);
		$admin_attributes = $admin->attributes();

		$this->assertInternalType('array', $admin_attributes);
		$this->assertTrue(array_key_exists("id", $admin_attributes));
		$this->assertFalse(array_key_exists("created_date", $admin_attributes));
		$this->assertEquals($admin_attributes['id'], 1);
	}

	/** @test */
	public function create_function_should_return_true_when_new_admin_created(){

		$admin = \Mockery::mock('\App\Includes\Admin[create]');
		$admin->shouldReceive('create')->andReturnUsing(function () {
			$db_fields = array('id', 'email', 'password', 'first_name', 'last_name', 'type', 'healthy_center_id');
			$attributes = array();
			$db_array = array();

			foreach($db_fields as $field) {
				if(property_exists(\App\Includes\Admin::class, $field)) {
					$attributes[$field] = $this->details[1][$field];
				}
			}

			$db_array[0] = array();
			foreach ($attributes as $key => $value) {
				$db_array[0][$key] = $value;	
			}

			if($db_array[0]["id"] == $attributes['id']){
				return true;
			} else {	
				return false;
			}
		});

		foreach ($this->details[1] as $key => $value) {
			$admin->$key = $value;
		}

		$createStatus = $admin->create();

		$this->assertTrue($createStatus);
	}

	/** @test */
	public function update_function_should_return_true_if_admin_has_updated(){

		$admin = \Mockery::mock('\App\Includes\Admin[update]');
		$admin->shouldReceive('update')->andReturnUsing(function () {
			$c_date = strftime("%Y-%m-%d %H:%M:%S", time());
			$db_array = array(
					$this->details[0]
				);

			$new_array = $this->details[0];
			$new_array['email'] = 'update@test.com';

			$db_array[$new_array['id']] = $new_array;

			if($db_array[$new_array['id']] == $new_array){
				return true;
			} else {	
				return false;
			}
		});
		$updateStatus = $admin->update();

		$this->assertTrue($updateStatus);
	}

	/** @test */
	public function delete_function_should_return_true_if_admin_has_deleted(){

		$admin = \Mockery::mock('\App\Includes\Admin[delete]');
		$admin->shouldReceive('delete')->andReturnUsing(function () {
			$db_array = array(
					$this->details[1]
				);

			$db_array[0] = null;

			if($db_array[0] == null){
				return true;
			} else {	
				return false;
			}
		});
		$deleteStatus = $admin->delete();

		$this->assertTrue($deleteStatus);
	}


}