<?php

class PostTest extends \PHPUnit_Framework_TestCase
{
	protected $details;

	public function setUp(){
		$this->details = array(
			array('id' => 0, 
				'created_date' => strftime("%Y-%m-%d %H:%M:%S", time()), 
				'author' => 'author one', 
				'body' => 'post bopdy'),
			array('id' => 1, 
				'created_date' => strftime("%Y-%m-%d %H:%M:%S", time()), 
				'author' => 'author one', 
				'body' => 'post body')
		);
	}	

	/** @test */
    public function make_function_should_return_a_post_object(){

        $post = \App\Includes\Post::make($this->details[0]);

        $this->assertInstanceOF(\App\Includes\Post::class, $post);
        $this->assertEquals($post->author, 'author one');
    }

    /** @test */
    public function find_all_function_should_return_all_posts(){

        $post = \Mockery::mock('Post');
        $post->shouldReceive('find_all')->withNoArgs()->andReturnUsing(function () {
            $posts = array();
            for ($i=0; $i < count($this->details); $i++) { 
            	array_push($posts, \App\Includes\Post::make($this->details[$i]));
            }
            return $posts;
        });

        $posts = $post->find_all();

        $this->assertInternalType('array', $posts);
        $this->assertInstanceOF(\App\Includes\Post::class, $posts[0]);
    }

    /** @test */
    public function find_by_id_function_should_return_a_post_with_id(){

        $post = \Mockery::mock('post');
        $post->shouldReceive('find_by_id')->andReturnUsing(function ($id) {
            for ($i=0; $i < count($this->details); $i++) { 
				if($this->details[$i]['id'] == $id){
					return \App\Includes\Post::make($this->details[$i]);
				}
			}
			return false;
        });

        $mockedResultpost = $post->find_by_id(0);

        $this->assertInstanceOF(\App\Includes\Post::class, $mockedResultpost);
        $this->assertEquals($mockedResultpost->id, 0);
    }

    /** @test */
    public function instantiate_function_should_return_a_post_instance(){

    	$post = \App\Includes\Post::instantiate($this->details[0]);

    	$this->assertInstanceOF(\App\Includes\Post::class, $post);
    	$this->assertEquals($post->id, 0);
    	$this->assertEquals($post->author, 'author one');
	}

	/** @test */
	public function has_attribute_function_should_return_true_if_post_has_an_attribute(){

		$post = new \App\Includes\Post();

		$this->assertTrue($post->has_attribute("id"));
		$this->assertTrue($post->has_attribute("author"));
		$this->assertFalse($post->has_attribute("full_name"));
	}

	/** @test */
	public function attributes_function_should_return_array_of_attributes(){

		$post = \App\Includes\Post::make($this->details[1]);
		$post_attributes = $post->attributes();

		$this->assertInternalType('array', $post_attributes);
		$this->assertTrue(array_key_exists("id", $post_attributes));
		$this->assertFalse(array_key_exists("name", $post_attributes));
		$this->assertEquals($post_attributes['id'], 1);
	}

	/** @test */
	public function create_function_should_return_true_when_new_post_created(){

		$post = \Mockery::mock('\App\Includes\Post[create]');
		$post->shouldReceive('create')->andReturnUsing(function () {
			$db_fields = array('id', 'created_date', 'author', 'body');
			$attributes = array();
			$db_array = array();

			foreach($db_fields as $field) {
				if(property_exists(\App\Includes\Post::class, $field)) {
					$attributes[$field] = $this->details[1][$field];
				}
			}

			$db_array[0] = array();
			foreach ($attributes as $key => $value) {
				$db_array[0][$key] = $value;	
			}

			if($db_array[0]["id"] == $attributes['id']){
				return true;
			} else {	
				return false;
			}
		});

		foreach ($this->details[1] as $key => $value) {
			$post->$key = $value;
		}

		$createStatus = $post->create();

		$this->assertTrue($createStatus);
	}

	/** @test */
	public function update_function_should_return_true_if_post_has_updated(){

		$post = \Mockery::mock('\App\Includes\Post[update]');
		$post->shouldReceive('update')->andReturnUsing(function () {
			$db_array = array(
					$this->details[0]
				);

			$new_array = $this->details[0];
			$new_array['name'] = 'new health name';

			$db_array[$new_array['id']] = $new_array;

			if($db_array[$new_array['id']] == $new_array){
				return true;
			} else {	
				return false;
			}
		});
		$updateStatus = $post->update();

		$this->assertTrue($updateStatus);
	}

	/** @test */
	public function delete_function_should_return_true_if_post_has_deleted(){

		$post = \Mockery::mock('\App\Includes\Post[delete]');
		$post->shouldReceive('delete')->andReturnUsing(function () {
			$db_array = array(
					$this->details[1]
				);

			$db_array[0] = null;

			if($db_array[0] == null){
				return true;
			} else {	
				return false;
			}
		});
		$deleteStatus = $post->delete();

		$this->assertTrue($deleteStatus);
	}
}