<?php

class DiseaseCategoryTest extends \PHPUnit_Framework_TestCase
{
	protected $details;

	public function setUp(){
		$this->details = array(
			array('id' => 0, 'category_name' => 'cate one'),
			array('id' => 1, 'category_name' => 'cate two')
		);
	}	

	/** @test */
    public function make_function_should_return_a_diseaseCategory_object(){

        $diseaseCategory = \App\Includes\DiseaseCategory::make($this->details[0]);

        $this->assertInstanceOF(\App\Includes\DiseaseCategory::class, $diseaseCategory);
        $this->assertEquals($diseaseCategory->category_name, 'cate one');
    }

    /** @test */
    public function find_all_function_should_return_all_diseaseCategorys(){

        $diseaseCategory = \Mockery::mock('diseaseCategory');
        $diseaseCategory->shouldReceive('find_all')->withNoArgs()->andReturnUsing(function () {
            $diseaseCategorys = array();
            for ($i=0; $i < count($this->details); $i++) { 
            	array_push($diseaseCategorys, \App\Includes\DiseaseCategory::make($this->details[$i]));
            }
            return $diseaseCategorys;
        });

        $diseaseCategorys = $diseaseCategory->find_all();

        $this->assertInternalType('array', $diseaseCategorys);
        $this->assertInstanceOF(\App\Includes\DiseaseCategory::class, $diseaseCategorys[0]);
    }

    /** @test */
    public function find_by_id_function_should_return_a_diseaseCategory_with_id(){

        $diseaseCategory = \Mockery::mock('diseaseCategory');
        $diseaseCategory->shouldReceive('find_by_id')->andReturnUsing(function ($id) {
            for ($i=0; $i < count($this->details); $i++) { 
				if($this->details[$i]['id'] == $id){
					return \App\Includes\DiseaseCategory::make($this->details[$i]);
				}
			}
			return false;
        });

        $mockedResultdiseaseCategory = $diseaseCategory->find_by_id(0);

        $this->assertInstanceOF(\App\Includes\DiseaseCategory::class, $mockedResultdiseaseCategory);
        $this->assertEquals($mockedResultdiseaseCategory->id, 0);
    }

    /** @test */
    public function instantiate_function_should_return_a_diseaseCategory_instance(){

    	$diseaseCategory = \App\Includes\DiseaseCategory::instantiate($this->details[0]);

    	$this->assertInstanceOF(\App\Includes\DiseaseCategory::class, $diseaseCategory);
    	$this->assertEquals($diseaseCategory->id, 0);
    	$this->assertEquals($diseaseCategory->category_name, 'cate one');
	}

	/** @test */
	public function has_attribute_function_should_return_true_if_diseaseCategory_has_an_attribute(){

		$diseaseCategory = new \App\Includes\DiseaseCategory();

		$this->assertTrue($diseaseCategory->has_attribute("id"));
		$this->assertTrue($diseaseCategory->has_attribute("category_name"));
		$this->assertFalse($diseaseCategory->has_attribute("full_name"));
	}

	/** @test */
	public function attributes_function_should_return_array_of_attributes(){

		$diseaseCategory = \App\Includes\DiseaseCategory::make($this->details[1]);
		$diseaseCategory_attributes = $diseaseCategory->attributes();

		$this->assertInternalType('array', $diseaseCategory_attributes);
		$this->assertTrue(array_key_exists("id", $diseaseCategory_attributes));
		$this->assertFalse(array_key_exists("created_date", $diseaseCategory_attributes));
		$this->assertEquals($diseaseCategory_attributes['id'], 1);
	}

	/** @test */
	public function create_function_should_return_true_when_new_diseaseCategory_created(){

		$diseaseCategory = \Mockery::mock('\App\Includes\DiseaseCategory[create]');
		$diseaseCategory->shouldReceive('create')->andReturnUsing(function () {
			$db_fields = array('id', 'category_name');
			$attributes = array();
			$db_array = array();

			foreach($db_fields as $field) {
				if(property_exists(\App\Includes\DiseaseCategory::class, $field)) {
					$attributes[$field] = $this->details[1][$field];
				}
			}

			$db_array[0] = array();
			foreach ($attributes as $key => $value) {
				$db_array[0][$key] = $value;	
			}

			if($db_array[0]["id"] == $attributes['id']){
				return true;
			} else {	
				return false;
			}
		});

		foreach ($this->details[1] as $key => $value) {
			$diseaseCategory->$key = $value;
		}

		$createStatus = $diseaseCategory->create();

		$this->assertTrue($createStatus);
	}

	/** @test */
	public function update_function_should_return_true_if_diseaseCategory_has_updated(){

		$diseaseCategory = \Mockery::mock('\App\Includes\DiseaseCategory[update]');
		$diseaseCategory->shouldReceive('update')->andReturnUsing(function () {
			$db_array = array(
					$this->details[0]
				);

			$new_array = $this->details[0];
			$new_array['category_name'] = 'new cate name';

			$db_array[$new_array['id']] = $new_array;

			if($db_array[$new_array['id']] == $new_array){
				return true;
			} else {	
				return false;
			}
		});
		$updateStatus = $diseaseCategory->update();

		$this->assertTrue($updateStatus);
	}

	/** @test */
	public function delete_function_should_return_true_if_diseaseCategory_has_deleted(){

		$diseaseCategory = \Mockery::mock('\App\Includes\DiseaseCategory[delete]');
		$diseaseCategory->shouldReceive('delete')->andReturnUsing(function () {
			$db_array = array(
					$this->details[1]
				);

			$db_array[0] = null;

			if($db_array[0] == null){
				return true;
			} else {	
				return false;
			}
		});
		$deleteStatus = $diseaseCategory->delete();

		$this->assertTrue($deleteStatus);
	}
}