<?php

class CommentTest extends \PHPUnit_Framework_TestCase
{	

	/** @test */
    public function make_function_should_return_a_comment_object(){

        $comment = \App\Includes\Comment::make(2, "comment_body");

        $OracleComment = new \App\Includes\Comment();
        $OracleComment->posts_id = (int) 2;
        $OracleComment->created_date= strftime("%Y-%m-%d %H:%M:%S", time());
        $OracleComment->body = "comment_body";

        $this->assertEquals($comment, $OracleComment);
    }

    /** @test */
    public function find_all_function_should_return_all_comments(){

        $comment = \Mockery::mock('comment');
        $comment->shouldReceive('find_all')->withNoArgs()->andReturnUsing(function () {
            $ReturnComment = new \App\Includes\Comment();
            $ReturnComment->posts_id = 5;
            $ReturnComment->created_date= strftime("%Y-%m-%d %H:%M:%S", time());
            $ReturnComment->body = "comment_body";
            return array($ReturnComment);
        });

        $comments = $comment->find_all();

        $this->assertInternalType('array', $comments);
        $this->assertInstanceOF(\App\Includes\Comment::class, $comments[0]);
        $this->assertEquals($comments[0]->posts_id, 5);
    }

    /** @test */
    public function find_by_post_id_function_should_return_comment_with_post_id(){

        $comment = \Mockery::mock('comment');
        $comment->shouldReceive('find_by_post_id')->andReturnUsing(function ($pid) {
            $ReturnComment = new \App\Includes\Comment();
            $ReturnComment->posts_id = (int) $pid;
            $ReturnComment->created_date= strftime("%Y-%m-%d %H:%M:%S", time());
            $ReturnComment->body = "comment_body";
            return $ReturnComment;
        });

        $mockedResultComment = $comment->find_by_post_id(3);

        $this->assertInstanceOF(\App\Includes\Comment::class, $mockedResultComment);
        $this->assertEquals($mockedResultComment->posts_id, 3);
    }

    /** @test */
    public function find_by_id_function_should_return_a_comment_with_id(){

        $comment = \Mockery::mock('comment');
        $comment->shouldReceive('find_by_id')->andReturnUsing(function ($id) {
            $ReturnComment = new \App\Includes\Comment();
            $ReturnComment->id = (int) $id;
            $ReturnComment->posts_id = 5;
            $ReturnComment->created_date= strftime("%Y-%m-%d %H:%M:%S", time());
            $ReturnComment->body = "comment_body";
            return $ReturnComment;
        });

        $mockedResultComment = $comment->find_by_id(10);

        $this->assertInstanceOF(\App\Includes\Comment::class, $mockedResultComment);
        $this->assertEquals($mockedResultComment->id, 10);
    }

    /** @test */
    public function instantiate_function_should_return_a_comment_instance(){

    	$row_data = array("id"=>2, 
    					  "posts_id"=>5, 
    					  "created_date"=>strftime("%Y-%m-%d %H:%M:%S", time()), 
    					  "body"=>"row data body");

    	$comment = \App\Includes\Comment::instantiate($row_data);

    	$this->assertInstanceOF(\App\Includes\Comment::class, $comment);
    	$this->assertEquals($comment->id, $row_data["id"]);
    	$this->assertEquals($comment->created_date, $row_data["created_date"]);
	}

	/** @test */
	public function has_attribute_function_should_return_true_if_comment_has_an_attribute(){

		$comment = new \App\Includes\Comment();

		$this->assertTrue($comment->has_attribute("id"));
		$this->assertTrue($comment->has_attribute("posts_id"));
		$this->assertFalse($comment->has_attribute("content"));
	}

	/** @test */
	public function attributes_function_should_return_array_of_attributes(){

		$comment = \App\Includes\Comment::make(4, "comment body");
		$comment_attributes = $comment->attributes();

		$this->assertInternalType('array', $comment_attributes);
		$this->assertTrue(array_key_exists("id", $comment_attributes));
		$this->assertTrue(array_key_exists("created_date", $comment_attributes));
		$this->assertEquals($comment_attributes['id'], null);
	}

	/** @test */
	public function create_function_should_return_true_when_new_comment_created(){

		$comment = \Mockery::mock('\App\Includes\Comment[create]');
		$comment->shouldReceive('create')->andReturnUsing(function () {
			$db_fields=array('id', 'posts_id', 'created_date', 'body');
			$attributes = array();
			$db_array = array();

			foreach($db_fields as $field) {
				if(property_exists($this, $field)) {
					$attributes[$field] = $this->$field;
				}
			}

			$attributes["id"] = 0;
			$db_array[0] = array();
			foreach ($attributes as $key => $value) {
				$db_array[0][$key] = $value;	
			}

			if($db_array[0]["id"] == 0){
				return true;
			} else {	
				return false;
			}
		});
		$comment->posts_id = 4;
		$comment->body = "comment body";
		$comment->created_date= strftime("%Y-%m-%d %H:%M:%S", time());

		$createStatus = $comment->create();

		$this->assertTrue($createStatus);
	}

	/** @test */
	public function update_function_should_return_true_if_comment_has_updated(){

		$comment = \Mockery::mock('\App\Includes\Comment[update]');
		$comment->shouldReceive('update')->andReturnUsing(function () {
			$c_date = strftime("%Y-%m-%d %H:%M:%S", time());
			$db_array = array(
					array(
						'id' => 0, 
						'posts_id' => 2, 
						'created_date' => $c_date, 
						'body' => "comment body"
					)
				);

			$new_array = array(
						'id' => 0, 
						'posts_id' => 2, 
						'created_date' => $c_date, 
						'body' => "comment body is updated"
					);

			$db_array[$new_array['id']] = $new_array;

			if($db_array[$new_array['id']] == $new_array){
				return true;
			} else {	
				return false;
			}
		});
		$updateStatus = $comment->update();

		$this->assertTrue($updateStatus);
	}

	/** @test */
	public function delete_function_should_return_true_if_comment_has_deleted(){

		$comment = \Mockery::mock('\App\Includes\Comment[delete]');
		$comment->shouldReceive('delete')->andReturnUsing(function () {
			$db_array = array(
					array(
						'id' => 0, 
						'posts_id' => 2, 
						'created_date' => strftime("%Y-%m-%d %H:%M:%S", time()), 
						'body' => "comment body"
					)
				);

			$db_array[0] = null;

			if($db_array[0] == null){
				return true;
			} else {	
				return false;
			}
		});
		$deleteStatus = $comment->delete();

		$this->assertTrue($deleteStatus);
	}


}