<?php

class DiseaseTest extends \PHPUnit_Framework_TestCase
{
	protected $details;

	public function setUp(){
		$this->details = array(
			array('id' => 0,
						'category_id' => 2, 
    					'name' => 'aintFun', 
    					'img' => 'aintFunImg', 
    					'discription' => 'aintFun discription'),
			array('id' => 1,
						'category_id' => 4, 
    					'name' => 'sucks', 
    					'img' => 'sucksImg', 
    					'discription' => 'sucks discription')
		);
	}	

	/** @test */
    public function make_function_should_return_a_disease_object(){

        $disease = \App\Includes\Disease::make($this->details[0]);

        $this->assertInstanceOF(\App\Includes\Disease::class, $disease);
        $this->assertEquals($disease->name, 'aintFun');
    }

    /** @test */
    public function find_all_function_should_return_all_diseases(){

        $disease = \Mockery::mock('disease');
        $disease->shouldReceive('find_all')->withNoArgs()->andReturnUsing(function () {
            $diseases = array();
            for ($i=0; $i < count($this->details); $i++) { 
            	array_push($diseases, \App\Includes\Disease::make($this->details[$i]));
            }
            return $diseases;
        });

        $diseases = $disease->find_all();

        $this->assertInternalType('array', $diseases);
        $this->assertInstanceOF(\App\Includes\Disease::class, $diseases[0]);
    }

    /** @test */
    public function find_by_id_function_should_return_a_disease_with_id(){

        $disease = \Mockery::mock('disease');
        $disease->shouldReceive('find_by_id')->andReturnUsing(function ($id) {
            for ($i=0; $i < count($this->details); $i++) { 
				if($this->details[$i]['id'] == $id){
					return \App\Includes\Disease::make($this->details[$i]);
				}
			}
			return false;
        });

        $mockedResultdisease = $disease->find_by_id(0);

        $this->assertInstanceOF(\App\Includes\Disease::class, $mockedResultdisease);
        $this->assertEquals($mockedResultdisease->id, 0);
    }

    /** @test */
    public function instantiate_function_should_return_a_disease_instance(){

    	$disease = \App\Includes\Disease::instantiate($this->details[0]);

    	$this->assertInstanceOF(\App\Includes\Disease::class, $disease);
    	$this->assertEquals($disease->id, 0);
    	$this->assertEquals($disease->name, 'aintFun');
	}

	/** @test */
	public function has_attribute_function_should_return_true_if_disease_has_an_attribute(){

		$disease = new \App\Includes\Disease();

		$this->assertTrue($disease->has_attribute("id"));
		$this->assertTrue($disease->has_attribute("name"));
		$this->assertFalse($disease->has_attribute("full_name"));
	}

	/** @test */
	public function attributes_function_should_return_array_of_attributes(){

		$disease = \App\Includes\Disease::make($this->details[1]);
		$disease_attributes = $disease->attributes();

		$this->assertInternalType('array', $disease_attributes);
		$this->assertTrue(array_key_exists("id", $disease_attributes));
		$this->assertFalse(array_key_exists("created_date", $disease_attributes));
		$this->assertEquals($disease_attributes['id'], 1);
	}

	/** @test */
	public function create_function_should_return_true_when_new_disease_created(){

		$disease = \Mockery::mock('\App\Includes\Disease[create]');
		$disease->shouldReceive('create')->andReturnUsing(function () {
			$db_fields = array('id', 'category_id', 'name', 'img', 'discription');
			$attributes = array();
			$db_array = array();

			foreach($db_fields as $field) {
				if(property_exists(\App\Includes\Disease::class, $field)) {
					$attributes[$field] = $this->details[1][$field];
				}
			}

			$db_array[0] = array();
			foreach ($attributes as $key => $value) {
				$db_array[0][$key] = $value;	
			}

			if($db_array[0]["id"] == $attributes['id']){
				return true;
			} else {	
				return false;
			}
		});

		foreach ($this->details[1] as $key => $value) {
			$disease->$key = $value;
		}

		$createStatus = $disease->create();

		$this->assertTrue($createStatus);
	}

	/** @test */
	public function update_function_should_return_true_if_disease_has_updated(){

		$disease = \Mockery::mock('\App\Includes\Disease[update]');
		$disease->shouldReceive('update')->andReturnUsing(function () {
			$db_array = array(
					$this->details[0]
				);

			$new_array = $this->details[0];
			$new_array['name'] = 'cring baby';

			$db_array[$new_array['id']] = $new_array;

			if($db_array[$new_array['id']] == $new_array){
				return true;
			} else {	
				return false;
			}
		});
		$updateStatus = $disease->update();

		$this->assertTrue($updateStatus);
	}

	/** @test */
	public function delete_function_should_return_true_if_disease_has_deleted(){

		$disease = \Mockery::mock('\App\Includes\Disease[delete]');
		$disease->shouldReceive('delete')->andReturnUsing(function () {
			$db_array = array(
					$this->details[1]
				);

			$db_array[0] = null;

			if($db_array[0] == null){
				return true;
			} else {	
				return false;
			}
		});
		$deleteStatus = $disease->delete();

		$this->assertTrue($deleteStatus);
	}
}